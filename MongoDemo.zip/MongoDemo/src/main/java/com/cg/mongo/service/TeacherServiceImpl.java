package com.cg.mongo.service;

import java.util.List;

import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.mongo.entity.Teacher;
import com.cg.mongo.repository.TeacherRepository;

@Service
public class TeacherServiceImpl implements TeacherService {
	
	
	private TeacherRepository repository;
	
	  @Autowired
	  public TeacherServiceImpl(TeacherRepository repository) {
	        this.repository = repository;
	    }

	@Override
	public List<Teacher> getAllTeacherInfo() {
		
		return repository.findAll();
	}

	@Override
	public Teacher getTeacherById(ObjectId id) {
		
		return repository.findBy_id(id);
	}

}
