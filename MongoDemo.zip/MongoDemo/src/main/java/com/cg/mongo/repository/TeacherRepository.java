package com.cg.mongo.repository;

import java.util.List;

import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.MongoRepository;
//import org.springframework.stereotype.Repository;

import com.cg.mongo.entity.Teacher;


public interface TeacherRepository extends MongoRepository<Teacher, String> {

	Teacher findBy_id(ObjectId id);

	
}
