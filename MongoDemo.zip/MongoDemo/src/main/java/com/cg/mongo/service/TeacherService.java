package com.cg.mongo.service;

import java.util.List;

import org.bson.types.ObjectId;

import com.cg.mongo.entity.Teacher;

public interface TeacherService {

	List<Teacher> getAllTeacherInfo();
	Teacher getTeacherById(ObjectId id);
	
}
