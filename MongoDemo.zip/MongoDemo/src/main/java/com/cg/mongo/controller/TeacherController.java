
package com.cg.mongo.controller;

import java.util.List;

import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.mongo.entity.Teacher;
import com.cg.mongo.service.TeacherService;


@RestController

public class TeacherController {

	@Autowired
	private TeacherService service;
	
	@GetMapping("/teachers")
	public List<Teacher> getAllStudentInfo()
	{
		return service.getAllTeacherInfo();
	}
	
	@RequestMapping(value = "/searchbyid/{id}", method = RequestMethod.GET)
	public Teacher getTeacherById(@PathVariable("id") ObjectId id) {
	  return service.getTeacherById(id);
	}
	
}
